(function () {
    // ===== Project Data =====
    const projects = [
        {
            name: "caffe FxP",
            description:
                "mempelajari bootstrap dan menerapkannya bersama fatah.",
            date: "31-08-26",
            tags: ["Dashboard", "Analytics", "Frontend"],
            path: "./2/index.html"
        },
        {
            name: "project tabel",
            description:
                "membuat tabel data diri yg ditugaskan oleh pak Luthfi.",
            date: "03-08-26",
            tags: ["E-Commerce", "Fullstack", "UI/UX"],
            path: "./1/index.html"
        }
    ];

    // ===== DOM References =====
    const grid = document.getElementById("projectGrid");
    const searchInput = document.getElementById("searchInput");
    const searchClear = document.getElementById("searchClear");
    const searchContainer = document.getElementById("searchContainer");
    const notFound = document.getElementById("notFound");
    const notFoundQuery = document.getElementById("notFoundQuery");
    const resultsInfo = document.getElementById("resultsInfo");
    const resultsCount = document.getElementById("resultsCount");
    const totalProjectsInfo = document.getElementById("totalProjectsInfo");
    const totalCount = document.getElementById("totalCount");

    // ===== State =====
    let currentFilter = "";

    // ===== Helper: Escape HTML =====
    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    // ===== Render Projects =====
    function renderProjects(filterText) {
        const query = filterText.trim().toLowerCase();
        currentFilter = query;

        // Filter projects by name (and optionally tags)
        const filtered = projects.filter(p => {
            if (!query) return true;
            const nameMatch = p.name.toLowerCase().includes(query);
            const tagMatch = p.tags.some(t => t.toLowerCase().includes(query));
            const descMatch = p.description.toLowerCase().includes(query);
            return nameMatch || tagMatch || descMatch;
        });

        // Sort: name matches first, then others
        if (query) {
            filtered.sort((a, b) => {
                const aName = a.name.toLowerCase().startsWith(query) ? 0 : 1;
                const bName = b.name.toLowerCase().startsWith(query) ? 0 : 1;
                return aName - bName;
            });
        }

        // Update counts
        const total = projects.length;
        totalCount.textContent = total;
        totalProjectsInfo.textContent = total;
        resultsCount.textContent = filtered.length;

        // Update results info visibility
        if (query && filtered.length > 0) {
            resultsInfo.textContent =
                "Menampilkan " +
                filtered.length +
                " dari " +
                total +
                ' project untuk "' +
                escapeHtml(query) +
                '"';
        } else if (query && filtered.length === 0) {
            resultsInfo.textContent = "";
        } else {
            resultsInfo.textContent =
                "Menampilkan " + total + " dari " + total + " project";
        }
        // Re-append highlight spans for styling
        if (query && filtered.length > 0) {
            resultsInfo.innerHTML =
                'Menampilkan <span class="highlight">' +
                filtered.length +
                "</span> dari <span>" +
                total +
                '</span> project untuk "<span class="highlight">' +
                escapeHtml(query) +
                '</span>"';
        } else if (query && filtered.length === 0) {
            resultsInfo.textContent = "";
        } else {
            resultsInfo.innerHTML =
                'Menampilkan <span class="highlight">' +
                total +
                "</span> dari <span>" +
                total +
                "</span> project";
        }

        // Toggle not found message
        if (filtered.length === 0) {
            notFound.classList.add("visible");
            notFoundQuery.textContent = '"' + filterText.trim() + '"';
            grid.style.display = "none";
        } else {
            notFound.classList.remove("visible");
            grid.style.display = "grid";
        }

        // Build HTML
        let html = "";
        filtered.forEach((project, index) => {
            const tagsHtml = project.tags
                .map(
                    tag =>
                        '<span class="card-tag">' + escapeHtml(tag) + "</span>"
                )
                .join("");

            html += `
                        <div class="project-card" style="animation-delay: ${(index * 0.06).toFixed(2)}s" data-name="${escapeHtml(project.name.toLowerCase())}">
                            <div class="card-header">
                                <h3 class="card-title">${escapeHtml(project.name)}</h3>
                                <span class="card-badge-date">${escapeHtml(project.date)}</span>
                            </div>
                            <p class="card-description">${escapeHtml(project.description)}</p>
                            <div class="card-tags">${tagsHtml}</div>
                            <a href="${escapeHtml(project.path)}" class="card-action" target="_blank" rel="noopener noreferrer">
                                Launch Project
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="5" y1="12" x2="19" y2="12"/>
                                    <polyline points="12 5 19 12 12 19"/>
                                </svg>
                            </a>
                        </div>
                    `;
        });

        grid.innerHTML = html;
    }

    // ===== Event Listeners =====
    searchInput.addEventListener("input", function (e) {
        renderProjects(e.target.value);
        // Toggle clear button
        if (e.target.value.length > 0) {
            searchClear.classList.add("visible");
        } else {
            searchClear.classList.remove("visible");
        }
    });

    searchClear.addEventListener("click", function () {
        searchInput.value = "";
        searchClear.classList.remove("visible");
        renderProjects("");
        searchInput.focus();
    });

    // Click on search container focuses input
    searchContainer.addEventListener("click", function (e) {
        if (
            e.target !== searchInput &&
            e.target !== searchClear &&
            !searchClear.contains(e.target)
        ) {
            searchInput.focus();
        }
    });

    // Keyboard shortcut: Escape clears search
    document.addEventListener("keydown", function (e) {
        if (
            e.key === "Escape" &&
            document.activeElement === searchInput &&
            searchInput.value
        ) {
            searchInput.value = "";
            searchClear.classList.remove("visible");
            renderProjects("");
        }
        // "/" focuses search
        if (
            e.key === "/" &&
            document.activeElement !== searchInput &&
            !e.target.closest(".search-container")
        ) {
            e.preventDefault();
            searchInput.focus();
        }
    });

    // ===== Initialize =====
    renderProjects("");
    totalCount.textContent = projects.length;

    // ===== Console info =====
    console.log(
        "%c PPLG Project Hub ",
        "background: #0a0e17; color: #00f2fe; font-size: 16px; font-weight: bold; padding: 8px 16px; border-radius: 4px;"
    );
    console.log("Total projects loaded:", projects.length);
    console.log(
        'Tip: Tekan "/" untuk fokus pencarian, "Escape" untuk bersihkan.'
    );

    // ===== Subtle parallax on orbs (desktop only) =====
    if (window.innerWidth > 768) {
        document.addEventListener("mousemove", function (e) {
            const x = (e.clientX / window.innerWidth - 0.5) * 2;
            const y = (e.clientY / window.innerHeight - 0.5) * 2;
            const orb1 = document.querySelector(".orb-1");
            const orb2 = document.querySelector(".orb-2");
            const orb3 = document.querySelector(".orb-3");
            if (orb1)
                orb1.style.transform =
                    "translate(" + x * 15 + "px," + y * 15 + "px)";
            if (orb2)
                orb2.style.transform =
                    "translate(" + x * -20 + "px," + y * -20 + "px)";
            if (orb3)
                orb3.style.transform =
                    "translate(" + x * 10 + "px," + y * 10 + "px)";
        });
    }
})();
