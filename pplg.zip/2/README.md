tugas ini di buat pada 31 Agustus 2026
yang beranggotakan:
1. fatah (36)
2. panji (34)