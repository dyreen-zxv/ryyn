const API_KEY = 'sk_live_ced6326f3d54b739b4b2d40afad5408c7392061dfe738100';
const BASE_URL = 'https://api.sayabayar.com/v1';

const products = [
    {
        id: 1,
        name: "Coffee Latte",
        description: "Menu klasik dengan rasa yang kuat dan nikmat.",
        price: 20000,
        priceFormat: "Rp20.000",
        image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=600&h=400&fit=crop"
    },
    {
        id: 2,
        name: "Cappuccino",
        description: "Kopi dengan susu dan foam yang lembut.",
        price: 22000,
        priceFormat: "Rp22.000",
        image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=600&h=400&fit=crop"
    },
    {
        id: 3,
        name: "Americano",
        description: "Kopi hitam dengan rasa yang ringan.",
        price: 18000,
        priceFormat: "Rp18.000",
        image: "https://images.unsplash.com/photo-1551030173-122aabc4489c?w=600&h=400&fit=crop"
    },
    {
        id: 4,
        name: "Mocha",
        description: "Perpaduan kopi dan cokelat yang creamy.",
        price: 25000,
        priceFormat: "Rp25.000",
        image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&h=400&fit=crop"
    }
];

const productsContainer = document.getElementById("products");
let selectedProduct = null;
let currentInvoiceId = null;
let currentInvoiceData = null;

products.forEach(product => {
    productsContainer.innerHTML += `
        <div class="col">
            <div class="card shadow-sm h-100">
                <div class="ratio ratio-16x9">
                    <img src="${product.image}" class="card-img-top" alt="${product.name}" style="object-fit: cover;">
                </div>
                <div class="card-body">
                    <h5 class="card-title">
                        ${product.name}
                    </h5>
                    <p class="card-text">
                        ${product.description}
                    </p>
                    <p class="fw-bold mb-3" style="color: #4a2c2a;">
                        ${product.priceFormat}
                    </p>
                    <button class="btn btn-primary btn-beli" style="background-color: #4a2c2a; border-color: #4a2c2a;" data-product='${JSON.stringify(product)}'>
                        <i class="bi bi-cart"></i>
                        Beli
                    </button>
                </div>
            </div>
        </div>
    `;
});

document.querySelectorAll('.btn-beli').forEach(button => {
    button.addEventListener('click', function() {
        selectedProduct = JSON.parse(this.dataset.product);
        openPaymentModal(selectedProduct);
    });
});

function openPaymentModal(product) {
    const modal = new bootstrap.Modal(document.getElementById('paymentModal'));
    document.getElementById('orderDetail').textContent = product.name + ' - ' + product.description;
    document.getElementById('orderPrice').textContent = product.priceFormat;
    document.getElementById('paymentLoading').style.display = 'block';
    document.getElementById('paymentContent').style.display = 'none';
    document.getElementById('paymentResult').innerHTML = '<p class="text-muted small">Pilih metode pembayaran untuk melihat detail</p>';
    document.getElementById('confirmPaymentBtn').disabled = true;
    document.getElementById('paymentStatus').innerHTML = '';
    currentInvoiceId = null;
    currentInvoiceData = null;
    modal.show();
}

document.querySelectorAll('.payment-method').forEach(button => {
    button.addEventListener('click', function() {
        document.querySelectorAll('.payment-method').forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        const method = this.dataset.method;
        createInvoice(method);
    });
});

async function createInvoice(paymentMethod) {
    if (!selectedProduct) return;

    const loadingDiv = document.getElementById('paymentLoading');
    const contentDiv = document.getElementById('paymentContent');
    const resultDiv = document.getElementById('paymentResult');
    const statusDiv = document.getElementById('paymentStatus');
    const confirmBtn = document.getElementById('confirmPaymentBtn');

    loadingDiv.style.display = 'block';
    contentDiv.style.display = 'none';
    statusDiv.innerHTML = '';
    confirmBtn.disabled = true;

    const customerName = document.getElementById('customerName').value || 'Pelanggan FXP Coffee';
    const customerEmail = document.getElementById('customerEmail').value || 'customer@fxpcoffee.com';
    const customerPhone = document.getElementById('customerPhone').value || '';
    const couponCode = document.getElementById('couponCode').value || '';

    try {
        const invoiceData = {
            customer_name: customerName,
            customer_email: customerEmail,
            amount: selectedProduct.price,
            description: selectedProduct.name + ' - ' + selectedProduct.description,
            channel_preference: 'client',
            payment_method: paymentMethod,
            redirect_url: window.location.href,
            metadata: {
                phone: customerPhone,
                product_name: selectedProduct.name,
                product_id: selectedProduct.id,
                coupon_code: couponCode
            }
        };

        const response = await fetch(`${BASE_URL}/invoices`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': API_KEY
            },
            body: JSON.stringify(invoiceData)
        });

        const result = await response.json();

        if (result.success) {
            currentInvoiceId = result.data.id;
            currentInvoiceData = result.data;
            
            const orderData = {
                invoice_id: result.data.id,
                product_name: selectedProduct.name,
                amount: selectedProduct.price,
                customer_name: customerName,
                customer_email: customerEmail,
                phone: customerPhone,
                status: 'pending',
                created_at: new Date().toISOString()
            };
            localStorage.setItem('order_' + result.data.id, JSON.stringify(orderData));
            
            let paymentInfo = '';
            if (result.data.payment_channel) {
                const pc = result.data.payment_channel;
                paymentInfo = `
                    <div class="mb-2">
                        <strong>Metode:</strong> ${pc.channel_type || paymentMethod}
                    </div>
                    <div class="mb-2">
                        <strong>Jumlah Bayar:</strong> Rp${(pc.amount_to_pay || selectedProduct.price).toLocaleString()}
                    </div>
                    ${pc.qris_string ? `
                        <div class="mb-2">
                            <strong>QRIS:</strong>
                            <div class="text-center my-3">
                                <img src="https://chart.googleapis.com/chart?cht=qr&chs=250x250&chl=${encodeURIComponent(pc.qris_string)}&choe=UTF-8" 
                                     class="img-fluid" 
                                     style="max-width: 200px; border: 2px solid #ddd; border-radius: 8px; padding: 10px; background: white;"
                                     onerror="this.style.display='none'; document.getElementById('qris-fallback-${result.data.id}').style.display='block';">
                                <div id="qris-fallback-${result.data.id}" style="display:none;" class="text-center">
                                    <p class="text-muted">QR Code tidak dapat ditampilkan. Silakan gunakan tombol di bawah.</p>
                                </div>
                            </div>
                            <p class="small text-muted mt-1">Scan QR Code di atas untuk membayar</p>
                            <button class="btn btn-sm btn-outline-primary mt-1" onclick="copyQR('${pc.qris_string}')">
                                <i class="bi bi-copy"></i> Copy QR String
                            </button>
                        </div>
                    ` : ''}
                    ${pc.va_number ? `
                        <div class="mb-2">
                            <strong>Virtual Account:</strong> 
                            <span class="fw-bold">${pc.va_number}</span>
                            <button class="btn btn-sm btn-outline-primary ms-2" onclick="copyText('${pc.va_number}')">
                                <i class="bi bi-copy"></i>
                            </button>
                        </div>
                    ` : ''}
                    ${pc.account_name ? `
                        <div class="mb-2">
                            <strong>Nama Rekening:</strong> ${pc.account_name}
                        </div>
                    ` : ''}
                    <div class="mb-2">
                        <strong>Invoice:</strong> ${result.data.invoice_number || 'N/A'}
                    </div>
                    <div class="mb-2">
                        <strong>Status:</strong> <span class="badge bg-warning">${result.data.status}</span>
                    </div>
                    <div class="mb-2">
                        <strong>Expired:</strong> ${new Date(result.data.expired_at).toLocaleString()}
                    </div>
                    ${result.data.payment_url ? `
                        <div class="mt-2">
                            <a href="${result.data.payment_url}" target="_blank" class="btn btn-success w-100">
                                <i class="bi bi-box-arrow-up-right"></i> Buka Halaman Pembayaran
                            </a>
                        </div>
                    ` : ''}
                `;
            } else {
                paymentInfo = `
                    <div class="mb-2">
                        <strong>Invoice:</strong> ${result.data.invoice_number || 'N/A'}
                    </div>
                    <div class="mb-2">
                        <strong>Status:</strong> <span class="badge bg-warning">${result.data.status}</span>
                    </div>
                    ${result.data.payment_url ? `
                        <div class="mt-2">
                            <a href="${result.data.payment_url}" target="_blank" class="btn btn-success w-100">
                                <i class="bi bi-box-arrow-up-right"></i> Buka Halaman Pembayaran
                            </a>
                        </div>
                    ` : ''}
                `;
            }

            resultDiv.innerHTML = paymentInfo;
            confirmBtn.disabled = false;
            statusDiv.innerHTML = '<div class="alert alert-info">Silakan lakukan pembayaran sesuai instruksi di atas.</div>';

            confirmBtn.onclick = function() {
                checkPaymentStatus(currentInvoiceId);
            };

        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${result.error?.message || 'Gagal membuat invoice'}
                    ${result.error?.code ? `<br><small>Code: ${result.error.code}</small>` : ''}
                </div>
            `;
        }

    } catch (error) {
        console.error('Error creating invoice:', error);
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <strong>Error:</strong> ${error.message || 'Gagal terhubung ke server pembayaran'}
            </div>
        `;
    } finally {
        loadingDiv.style.display = 'none';
        contentDiv.style.display = 'block';
    }
}

async function checkPaymentStatus(invoiceId) {
    if (!invoiceId) return;

    const statusDiv = document.getElementById('paymentStatus');
    const confirmBtn = document.getElementById('confirmPaymentBtn');

    confirmBtn.disabled = true;
    statusDiv.innerHTML = '<div class="text-center"><div class="spinner-border spinner-border-sm text-primary" role="status"></div> Memeriksa status...</div>';

    try {
        const response = await fetch(`${BASE_URL}/invoices/${invoiceId}`, {
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': API_KEY
            }
        });

        const result = await response.json();

        if (result.success) {
            const status = result.data.status;
            
            const orderKey = 'order_' + invoiceId;
            const savedOrder = localStorage.getItem(orderKey);
            if (savedOrder) {
                const orderData = JSON.parse(savedOrder);
                orderData.status = status;
                localStorage.setItem(orderKey, JSON.stringify(orderData));
            }

            showStatusModal(status, result.data);
            
            if (status === 'paid') {
                statusDiv.innerHTML = '<div class="alert alert-success">Pembayaran berhasil! <i class="bi bi-check-circle-fill"></i></div>';
                document.getElementById('paymentModal').querySelector('.btn-close').click();
                setTimeout(() => {
                    window.location.href = window.location.href + '?payment=success';
                }, 1500);
            } else if (status === 'pending') {
                statusDiv.innerHTML = `
                    <div class="alert alert-warning">Pembayaran masih pending. <button class="btn btn-sm btn-outline-primary ms-2" onclick="checkPaymentStatus('${invoiceId}')"><i class="bi bi-arrow-repeat"></i> Cek Ulang</button></div>
                `;
                confirmBtn.disabled = false;
            } else if (status === 'expired') {
                statusDiv.innerHTML = '<div class="alert alert-danger">Pembayaran kadaluarsa. Silakan pesan ulang.</div>';
                confirmBtn.disabled = true;
            }
        } else {
            statusDiv.innerHTML = `<div class="alert alert-danger">${result.error?.message || 'Gagal cek status'}</div>`;
            confirmBtn.disabled = false;
        }
    } catch (error) {
        console.error('Error checking payment:', error);
        statusDiv.innerHTML = `<div class="alert alert-danger">${error.message || 'Gagal terhubung ke server'}</div>`;
        confirmBtn.disabled = false;
    }
}

function showStatusModal(status, data) {
    const statusModal = new bootstrap.Modal(document.getElementById('statusModal'));
    const icon = document.getElementById('statusIcon');
    const title = document.getElementById('statusTitle');
    const message = document.getElementById('statusMessage');
    const detail = document.getElementById('statusDetail');

    if (status === 'paid') {
        icon.innerHTML = '<i class="bi bi-check-circle-fill text-success"></i>';
        title.textContent = 'Pembayaran Berhasil!';
        title.style.color = '#28a745';
        message.textContent = 'Terima kasih! Pesanan Anda sudah kami terima.';
        detail.innerHTML = `
            <div class="p-3 bg-light rounded">
                <p><strong>Invoice:</strong> ${data.invoice_number || 'N/A'}</p>
                <p><strong>Jumlah:</strong> Rp${(data.amount || 0).toLocaleString()}</p>
                <p><strong>Status:</strong> <span class="badge bg-success">Lunas</span></p>
                <p><strong>Dibayar pada:</strong> ${data.paid_at ? new Date(data.paid_at).toLocaleString() : 'N/A'}</p>
            </div>
        `;
    } else if (status === 'pending') {
        icon.innerHTML = '<i class="bi bi-hourglass-split text-warning"></i>';
        title.textContent = 'Menunggu Pembayaran';
        title.style.color = '#ffc107';
        message.textContent = 'Pembayaran Anda masih dalam proses. Silakan cek kembali nanti.';
        detail.innerHTML = `
            <div class="p-3 bg-light rounded">
                <p><strong>Invoice:</strong> ${data.invoice_number || 'N/A'}</p>
                <p><strong>Status:</strong> <span class="badge bg-warning">Pending</span></p>
                <button class="btn btn-primary btn-sm mt-2" onclick="checkPaymentStatus('${data.id}')">
                    <i class="bi bi-arrow-repeat"></i> Cek Ulang
                </button>
            </div>
        `;
    } else if (status === 'expired') {
        icon.innerHTML = '<i class="bi bi-clock-fill text-danger"></i>';
        title.textContent = 'Pembayaran Kadaluarsa';
        title.style.color = '#dc3545';
        message.textContent = 'Waktu pembayaran sudah habis. Silakan pesan ulang.';
        detail.innerHTML = `
            <div class="p-3 bg-light rounded">
                <p><strong>Invoice:</strong> ${data.invoice_number || 'N/A'}</p>
                <p><strong>Status:</strong> <span class="badge bg-danger">Expired</span></p>
            </div>
        `;
    } else {
        icon.innerHTML = '<i class="bi bi-question-circle text-secondary"></i>';
        title.textContent = 'Status Tidak Diketahui';
        title.style.color = '#6c757d';
        message.textContent = 'Status pembayaran tidak dapat ditentukan.';
        detail.innerHTML = `
            <div class="p-3 bg-light rounded">
                <p><strong>Status:</strong> ${status}</p>
            </div>
        `;
    }

    statusModal.show();
}

function copyQR(qrString) {
    navigator.clipboard.writeText(qrString).then(() => {
        alert('QR String berhasil disalin!');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = qrString;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('QR String berhasil disalin!');
    });
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Nomor VA berhasil disalin!');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Nomor VA berhasil disalin!');
    });
}

window.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('payment') === 'success') {
        const keys = Object.keys(localStorage);
        const orderKeys = keys.filter(k => k.startsWith('order_'));
        if (orderKeys.length > 0) {
            const lastOrder = JSON.parse(localStorage.getItem(orderKeys[orderKeys.length - 1]));
            if (lastOrder.status === 'pending') {
                checkPaymentStatus(lastOrder.invoice_id);
            }
        }
    }
});

console.log('💳 FXP Coffee Payment System Ready!');
console.log('🔑 API Key:', API_KEY.substring(0, 20) + '...');